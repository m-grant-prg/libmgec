var buffer_8c =
[
    [ "concat_buf", "buffer_8c.html#a84f0acd02cc1377f3fa2e3ac9c3b9ec2", null ],
    [ "print_buf", "buffer_8c.html#a63abbd8a31e859f4879de5205d21fce1", null ],
    [ "print_def_buf_values", "buffer_8c.html#a595a873ce81c844e14591375c8210211", null ],
    [ "trim_buf", "buffer_8c.html#a39df69216e9e8bf96ab185e3b2d85090", null ]
];