var searchData=
[
  ['mgebuffer_130',['mgebuffer',['../structmgebuffer.html',1,'']]],
  ['mgemessage_131',['mgemessage',['../structmgemessage.html',1,'']]]
];
