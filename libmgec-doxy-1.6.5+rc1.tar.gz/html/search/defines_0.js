var searchData=
[
  ['_5f_5fbool_5ftrue_5ffalse_5fare_5fdefined_219',['__bool_true_false_are_defined',['../mgemessage_8h.html#a665b0cc9ee2ced31785321d55cde349e',1,'mgemessage.h']]],
  ['_5fbool_220',['_Bool',['../mgemessage_8h.html#aeaff0db5524987a2f50d71ac0162ceb2',1,'mgemessage.h']]]
];
