var searchData=
[
  ['mg_5frealloc_180',['mg_realloc',['../mgememory_8h.html#ab44db1d9231ab548a5d26e1483d54400',1,'mg_realloc(char *mem_ptr, const size_t mem_sz):&#160;memory.c'],['../memory_8c.html#aa3db0a40c0c4933a9683ba635a7324a7',1,'mg_realloc(char *mem_ptr, const size_t mem_sz):&#160;memory.c']]],
  ['mge_5fstrerror_181',['mge_strerror',['../mge-errno_8h.html#ad662b362519a8e8f9caf7c6462c38e37',1,'mge_strerror(const int mge_err):&#160;error.c'],['../error_8c.html#ad662b362519a8e8f9caf7c6462c38e37',1,'mge_strerror(const int mge_err):&#160;error.c']]]
];
