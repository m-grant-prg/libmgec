var searchData=
[
  ['del_5fbst_163',['del_bst',['../bstree_8h.html#aef02c9547b4c46ca56ddf7fa79046dda',1,'del_bst(struct bstree *tree):&#160;bstree.c'],['../bstree_8c.html#aef02c9547b4c46ca56ddf7fa79046dda',1,'del_bst(struct bstree *tree):&#160;bstree.c']]],
  ['del_5fbst_5fnode_164',['del_bst_node',['../bstree_8h.html#a54a009d4d10be3cfaeef8cd0933a8993',1,'del_bst_node(struct bstree *tree, const void *searchobj):&#160;bstree.c'],['../bstree_8c.html#a54a009d4d10be3cfaeef8cd0933a8993',1,'del_bst_node(struct bstree *tree, const void *searchobj):&#160;bstree.c']]]
];
