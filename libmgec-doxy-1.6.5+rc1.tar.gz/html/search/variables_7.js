var searchData=
[
  ['prevnode_209',['prevnode',['../structdllistnode.html#a9db52bb16f4ece555abca891a671c35f',1,'dllistnode']]],
  ['proc_5fnext_210',['proc_next',['../structmgebuffer.html#a3e5a8495bb79d164e56546437ac9b276',1,'mgebuffer']]]
];
