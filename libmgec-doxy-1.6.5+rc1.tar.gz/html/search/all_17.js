var searchData=
[
  ['xdir_124',['xdir',['../structbstobjcoord.html#a9158baa20c9c74fb5df5905386d9c4c8',1,'bstobjcoord']]]
];
