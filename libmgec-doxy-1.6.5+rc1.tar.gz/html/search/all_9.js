var searchData=
[
  ['del_5fbst_35',['del_bst',['../bstree_8h.html#aef02c9547b4c46ca56ddf7fa79046dda',1,'del_bst(struct bstree *tree):&#160;bstree.c'],['../bstree_8c.html#aef02c9547b4c46ca56ddf7fa79046dda',1,'del_bst(struct bstree *tree):&#160;bstree.c']]],
  ['del_5fbst_5fnode_36',['del_bst_node',['../bstree_8h.html#a54a009d4d10be3cfaeef8cd0933a8993',1,'del_bst_node(struct bstree *tree, const void *searchobj):&#160;bstree.c'],['../bstree_8c.html#a54a009d4d10be3cfaeef8cd0933a8993',1,'del_bst_node(struct bstree *tree, const void *searchobj):&#160;bstree.c']]],
  ['dllist_2ec_37',['dllist.c',['../dllist_8c.html',1,'']]],
  ['dllist_2eh_38',['dllist.h',['../dllist_8h.html',1,'']]],
  ['dllistnode_39',['dllistnode',['../structdllistnode.html',1,'']]]
];
