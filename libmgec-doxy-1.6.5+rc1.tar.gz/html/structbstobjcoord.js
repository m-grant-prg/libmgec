var structbstobjcoord =
[
    [ "count", "structbstobjcoord.html#ad43c3812e6d13e0518d9f8b8f463ffcf", null ],
    [ "object", "structbstobjcoord.html#a077376d12464f945e2414d5499c79b3f", null ],
    [ "xdir", "structbstobjcoord.html#a9158baa20c9c74fb5df5905386d9c4c8", null ],
    [ "ydir", "structbstobjcoord.html#ad26d97cdff72b7baf09cc7dab08ee6d7", null ]
];