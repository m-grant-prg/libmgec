var searchData=
[
  ['mgebuffer_147',['mgebuffer',['../structmgebuffer.html',1,'']]],
  ['mgemessage_148',['mgemessage',['../structmgemessage.html',1,'']]]
];
