var searchData=
[
  ['sav_5ferrno_246',['sav_errno',['../mge-errno_8h.html#aca21acb62828e1585d26cd8fe9ea3f56',1,'sav_errno():&#160;errno.c'],['../errno_8c.html#aca21acb62828e1585d26cd8fe9ea3f56',1,'sav_errno():&#160;errno.c']]],
  ['separator_247',['separator',['../structmgemessage.html#a6989953791434c8ea982054551c9e154',1,'mgemessage']]],
  ['size_248',['size',['../structmgebuffer.html#a854352f53b148adc24983a58a1866d66',1,'mgebuffer::size()'],['../structmgemessage.html#a854352f53b148adc24983a58a1866d66',1,'mgemessage::size()']]]
];
