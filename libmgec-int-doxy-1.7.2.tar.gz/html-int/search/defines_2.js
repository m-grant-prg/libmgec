var searchData=
[
  ['def_5fbuf_5fsize_259',['DEF_BUF_SIZE',['../buf-msg_2internal_8h.html#afaf870b3cd0c265f7222b27871894a7c',1,'internal.h']]],
  ['def_5fmsg_5fsize_260',['DEF_MSG_SIZE',['../buf-msg_2internal_8h.html#a433228a91a08544329fbdb9127073790',1,'internal.h']]]
];
