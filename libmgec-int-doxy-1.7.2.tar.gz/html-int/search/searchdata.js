var indexSectionsWithContent =
{
  0: "12345abcdefgilmnoprstuvxy",
  1: "bdms",
  2: "12345bdeilmsv",
  3: "acdfglmptu",
  4: "abcemnoprstuxy",
  5: "abdefmp",
  6: "aelmo"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables",
  5: "defines",
  6: "pages"
};

var indexSectionLabels =
{
  0: "All",
  1: "Data Structures",
  2: "Files",
  3: "Functions",
  4: "Variables",
  5: "Macros",
  6: "Pages"
};

