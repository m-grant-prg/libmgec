var structbstree =
[
    [ "comp", "structbstree.html#a4028e149ea0b364afc10a83eee6440fd", null ],
    [ "count_total", "structbstree.html#aacf29526945e0158819de7dc0624412b", null ],
    [ "node_total", "structbstree.html#a215aa978cf35bba1b267863484c9b026", null ],
    [ "root", "structbstree.html#ad549571392d4f2dbae0975d41d030206", null ],
    [ "unique", "structbstree.html#a0efb8e1dc5f53b2e2392c388cc651172", null ]
];