var errors_2internal_8h =
[
    [ "errno_desc", "errors_2internal_8h.html#a55a0bf450e3b12ff9a1af89fa1a63ac8", null ],
    [ "errno_desc_size", "errors_2internal_8h.html#afe6469842453c6f79aeba76379d7410e", null ]
];