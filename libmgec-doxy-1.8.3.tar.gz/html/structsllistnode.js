var structsllistnode =
[
    [ "next", "structsllistnode.html#a700fc56f215d3482e760ff98df3d5091", null ],
    [ "object", "structsllistnode.html#a077376d12464f945e2414d5499c79b3f", null ]
];