var structdllistnode =
[
    [ "nextnode", "structdllistnode.html#af7fc1f9f814200e46f63c2dc78476043", null ],
    [ "object", "structdllistnode.html#a077376d12464f945e2414d5499c79b3f", null ],
    [ "prevnode", "structdllistnode.html#a9db52bb16f4ece555abca891a671c35f", null ]
];