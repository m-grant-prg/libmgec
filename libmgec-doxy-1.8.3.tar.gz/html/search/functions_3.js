var searchData=
[
  ['del_5fbst_169',['del_bst',['../mge-bstree_8h.html#aef02c9547b4c46ca56ddf7fa79046dda',1,'del_bst(struct bstree *tree):&#160;bstree.c'],['../bstree_8c.html#aef02c9547b4c46ca56ddf7fa79046dda',1,'del_bst(struct bstree *tree):&#160;bstree.c']]],
  ['del_5fbst_5fnode_170',['del_bst_node',['../mge-bstree_8h.html#a54a009d4d10be3cfaeef8cd0933a8993',1,'del_bst_node(struct bstree *tree, const void *searchobj):&#160;bstree.c'],['../bstree_8c.html#a54a009d4d10be3cfaeef8cd0933a8993',1,'del_bst_node(struct bstree *tree, const void *searchobj):&#160;bstree.c']]],
  ['del_5fnode_171',['del_node',['../bstree_8c.html#ad6d6514682635e572bd8386dffdb4e78',1,'bstree.c']]]
];
