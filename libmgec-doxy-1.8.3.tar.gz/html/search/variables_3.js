var searchData=
[
  ['err_5fmsg_213',['err_msg',['../error_8c.html#ae6f93802039702880b0a18964f011dda',1,'error.c']]],
  ['errno_5fdesc_214',['errno_desc',['../errno_8c.html#a01f85b44e6028ea35547d68a8755303a',1,'errno.c']]],
  ['errno_5fdesc_5fsize_215',['errno_desc_size',['../errno_8c.html#afe6469842453c6f79aeba76379d7410e',1,'errno.c']]]
];
