var searchData=
[
  ['sav_5ferrno_119',['sav_errno',['../mge-errno_8h.html#aca21acb62828e1585d26cd8fe9ea3f56',1,'sav_errno():&#160;errno.c'],['../errno_8c.html#aca21acb62828e1585d26cd8fe9ea3f56',1,'sav_errno():&#160;errno.c']]],
  ['separator_120',['separator',['../structmgemessage.html#a6989953791434c8ea982054551c9e154',1,'mgemessage']]],
  ['size_121',['size',['../structmgebuffer.html#a854352f53b148adc24983a58a1866d66',1,'mgebuffer::size()'],['../structmgemessage.html#a854352f53b148adc24983a58a1866d66',1,'mgemessage::size()']]],
  ['sllist_2ec_122',['sllist.c',['../sllist_8c.html',1,'']]],
  ['sllist_2eh_123',['sllist.h',['../sllist_8h.html',1,'']]],
  ['sllistnode_124',['sllistnode',['../structsllistnode.html',1,'']]]
];
