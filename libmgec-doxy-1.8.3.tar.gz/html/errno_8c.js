var errno_8c =
[
    [ "errno_desc", "errno_8c.html#a01f85b44e6028ea35547d68a8755303a", null ],
    [ "errno_desc_size", "errno_8c.html#afe6469842453c6f79aeba76379d7410e", null ],
    [ "mge_errno", "errno_8c.html#a613adab9b3e56ac29558a2a9a0f28a89", null ],
    [ "sav_errno", "errno_8c.html#aca21acb62828e1585d26cd8fe9ea3f56", null ]
];