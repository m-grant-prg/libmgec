var searchData=
[
  ['mgebuffer_149',['mgebuffer',['../structmgebuffer.html',1,'']]],
  ['mgemessage_150',['mgemessage',['../structmgemessage.html',1,'']]]
];
