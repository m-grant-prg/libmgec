var mge_buffer_8h =
[
    [ "mgebuffer", "structmgebuffer.html", "structmgebuffer" ],
    [ "MGEBUFFER_INIT", "mge-buffer_8h.html#a0b97c4f59904c1f7c09c553b2d6590d8", null ],
    [ "concat_buf", "mge-buffer_8h.html#a84f0acd02cc1377f3fa2e3ac9c3b9ec2", null ],
    [ "print_buf", "mge-buffer_8h.html#a63abbd8a31e859f4879de5205d21fce1", null ],
    [ "print_def_buf_values", "mge-buffer_8h.html#a595a873ce81c844e14591375c8210211", null ],
    [ "trim_buf", "mge-buffer_8h.html#adb167a2d1c26596ae70f35c495cf5286", null ]
];