var searchData=
[
  ['sav_5ferrno_129',['sav_errno',['../mge-errno_8h.html#aca21acb62828e1585d26cd8fe9ea3f56',1,'sav_errno():&#160;errno.c'],['../errno_8c.html#aca21acb62828e1585d26cd8fe9ea3f56',1,'sav_errno():&#160;errno.c']]],
  ['separator_130',['separator',['../structmgemessage.html#a6989953791434c8ea982054551c9e154',1,'mgemessage']]],
  ['size_131',['size',['../structmgebuffer.html#a854352f53b148adc24983a58a1866d66',1,'mgebuffer::size()'],['../structmgemessage.html#a854352f53b148adc24983a58a1866d66',1,'mgemessage::size()']]],
  ['sllist_2ec_132',['sllist.c',['../sllist_8c.html',1,'']]],
  ['sllist_2eh_133',['sllist.h',['../sllist_8h.html',1,'']]],
  ['sllistnode_134',['sllistnode',['../structsllistnode.html',1,'']]]
];
