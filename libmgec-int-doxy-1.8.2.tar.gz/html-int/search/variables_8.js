var searchData=
[
  ['root_244',['root',['../structbstree.html#ad549571392d4f2dbae0975d41d030206',1,'bstree']]]
];
