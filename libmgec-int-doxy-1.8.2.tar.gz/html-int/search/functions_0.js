var searchData=
[
  ['_5f_5fattribute_5f_5f_175',['__attribute__',['../libmgec_8h.html#ab1f6a5fa068da4b54d854bc56affc54c',1,'__attribute__((const)) const char *libmgec_get_pkg_version(void):&#160;version.c'],['../version_8c.html#a699f6a3da91f9155d09cd12158ed6def',1,'__attribute__((const)) const:&#160;version.c']]]
];
