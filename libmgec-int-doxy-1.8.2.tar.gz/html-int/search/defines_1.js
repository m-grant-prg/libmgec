var searchData=
[
  ['begin_5fc_5fdecls_253',['BEGIN_C_DECLS',['../mge-portability_8h.html#a0c2d4d01206892eecb3fd695f45dec2d',1,'mge-portability.h']]],
  ['bst_5fnodes_5fduplicates_254',['BST_NODES_DUPLICATES',['../mge-bstree_8h.html#ab5e3644738fe364d904b7b4c357d0b85',1,'mge-bstree.h']]],
  ['bst_5fnodes_5funique_255',['BST_NODES_UNIQUE',['../mge-bstree_8h.html#a180030be5dfa39f8e9f9c985d24facfd',1,'mge-bstree.h']]],
  ['buf_5fmax_5funreach_5fpercent_256',['BUF_MAX_UNREACH_PERCENT',['../buf-msg_2internal_8h.html#aef7265c39900560924efc2ec8249e57a',1,'internal.h']]],
  ['buf_5funused_5fdef_5fsize_5fmult_257',['BUF_UNUSED_DEF_SIZE_MULT',['../buf-msg_2internal_8h.html#afe1cdd2b075547cfb54a1333cbcfbb70',1,'internal.h']]]
];
