var dir_d78e62a2cbd421971c1fc219a63b7a50 =
[
    [ "buffer.c", "buffer_8c.html", "buffer_8c" ],
    [ "internal.h", "buf-msg_2internal_8h.html", "buf-msg_2internal_8h" ],
    [ "message.c", "message_8c.html", "message_8c" ]
];