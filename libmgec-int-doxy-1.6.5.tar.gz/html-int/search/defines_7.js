var searchData=
[
  ['params_292',['PARAMS',['../portability_8h.html#a924645a9d5499fb2d2bdcfda8d3241f0',1,'portability.h']]]
];
