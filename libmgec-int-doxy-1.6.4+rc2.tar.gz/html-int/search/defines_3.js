var searchData=
[
  ['end_5fc_5fdecls_261',['END_C_DECLS',['../mge-portability_8h.html#ac17320fed4b28122bc4977a087b131dd',1,'mge-portability.h']]]
];
