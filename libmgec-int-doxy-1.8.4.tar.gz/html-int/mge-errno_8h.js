var mge_errno_8h =
[
    [ "MGE_CLIENT_BLOCKED", "mge-errno_8h.html#a90defc9e20a7fc7995b6144cdd3caf77", null ],
    [ "MGE_CONFIG_PARAM", "mge-errno_8h.html#a548cceba51b84017b2ac322f71abb890", null ],
    [ "MGE_CONFIG_PARSE", "mge-errno_8h.html#a8aae7f7daf6822a18ad40dacfd958762", null ],
    [ "MGE_DUPLICATE_NODE", "mge-errno_8h.html#a2d04bc2d31063f1d2d3d96494725ff43", null ],
    [ "MGE_ERRNO", "mge-errno_8h.html#a14fbe2084e7a6077a91baf28f573a034", null ],
    [ "MGE_GAI", "mge-errno_8h.html#a582599c3e2cf2f7ce3f04c6f42e74d9f", null ],
    [ "MGE_GAI_BIND", "mge-errno_8h.html#a1dd70a313e8531e6cb2dd52fb11868bc", null ],
    [ "MGE_GENERAL", "mge-errno_8h.html#a3c734d540b6e9d76ce350c6afbaa472b", null ],
    [ "MGE_ID", "mge-errno_8h.html#a7e755f6eef950aa13c03c3ae1f86de18", null ],
    [ "MGE_INVAL_MSG", "mge-errno_8h.html#acd20409e20c90e1d599ae69d22533d7f", null ],
    [ "MGE_LOCK_NOT_FOUND", "mge-errno_8h.html#aab83d4ea8a1b479fd0adec2151cb5679", null ],
    [ "MGE_NODE_NOT_FOUND", "mge-errno_8h.html#a8f10d59c086a2607a5e52a9a79c4d317", null ],
    [ "MGE_PARAM", "mge-errno_8h.html#acdcb3f533d5064d5ba56a299f1a26eab", null ],
    [ "MGE_PROTO", "mge-errno_8h.html#a58b5a4e3a77b6b63b7dad5f4c62d1dc2", null ],
    [ "MGE_SERVER_BLOCKED", "mge-errno_8h.html#ad6fdc59709912fa1cfa17dd043c0d80a", null ],
    [ "MGE_SSH", "mge-errno_8h.html#a5c2ee1e3995447a3e0401638423bf0af", null ],
    [ "mge_strerror", "mge-errno_8h.html#ad662b362519a8e8f9caf7c6462c38e37", null ],
    [ "mge_errno", "mge-errno_8h.html#a4a252afc0f63a2e93041fac39048678a", null ],
    [ "sav_errno", "mge-errno_8h.html#aca21acb62828e1585d26cd8fe9ea3f56", null ]
];