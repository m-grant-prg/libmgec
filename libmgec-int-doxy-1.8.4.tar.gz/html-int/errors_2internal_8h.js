var errors_2internal_8h =
[
    [ "errno_desc", "errors_2internal_8h.html#ac2014a6b50646452887af33b07c2a6df", null ],
    [ "errno_desc_size", "errors_2internal_8h.html#afe6469842453c6f79aeba76379d7410e", null ]
];