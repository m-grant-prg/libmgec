var searchData=
[
  ['mgebuffer_132',['mgebuffer',['../structmgebuffer.html',1,'']]],
  ['mgemessage_133',['mgemessage',['../structmgemessage.html',1,'']]]
];
