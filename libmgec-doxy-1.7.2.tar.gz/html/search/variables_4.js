var searchData=
[
  ['message_215',['message',['../structmgemessage.html#a0b2e8c7f76df48129f994ecc46d5c66c',1,'mgemessage']]],
  ['mge_5ferrno_216',['mge_errno',['../mge-errno_8h.html#a4a252afc0f63a2e93041fac39048678a',1,'mge_errno():&#160;errno.c'],['../errno_8c.html#a613adab9b3e56ac29558a2a9a0f28a89',1,'mge_errno():&#160;errno.c']]]
];
