var searchData=
[
  ['clear_5fmsg_163',['clear_msg',['../mge-message_8h.html#a0540546fe564b51dbccd55ba0f86ea2f',1,'clear_msg(struct mgemessage *msg, const char terminator, const char separator):&#160;message.c'],['../message_8c.html#a0540546fe564b51dbccd55ba0f86ea2f',1,'clear_msg(struct mgemessage *msg, const char terminator, const char separator):&#160;message.c']]],
  ['concat_5fbuf_164',['concat_buf',['../mge-buffer_8h.html#a84f0acd02cc1377f3fa2e3ac9c3b9ec2',1,'concat_buf(const char *s_buf, const size_t s_buf_os, struct mgebuffer *m_buf):&#160;buffer.c'],['../buffer_8c.html#a84f0acd02cc1377f3fa2e3ac9c3b9ec2',1,'concat_buf(const char *s_buf, const size_t s_buf_os, struct mgebuffer *m_buf):&#160;buffer.c']]],
  ['cre_5fbst_165',['cre_bst',['../mge-bstree_8h.html#a99224174bcdfc8d39c7a3aa23d0acf5e',1,'cre_bst(int unique, int(*comp)(const void *, const void *)):&#160;bstree.c'],['../bstree_8c.html#a99224174bcdfc8d39c7a3aa23d0acf5e',1,'cre_bst(int unique, int(*comp)(const void *, const void *)):&#160;bstree.c']]]
];
