var indexSectionsWithContent =
{
  0: "12345abcdefglmnoprstuv",
  1: "bdms",
  2: "12345bdelmsv",
  3: "acdfglmptu",
  4: "abcemnoprstu",
  5: "abefmp",
  6: "elmo"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables",
  5: "defines",
  6: "pages"
};

var indexSectionLabels =
{
  0: "All",
  1: "Data Structures",
  2: "Files",
  3: "Functions",
  4: "Variables",
  5: "Macros",
  6: "Pages"
};

