var structbstree =
[
    [ "comp", "structbstree.html#aafce86f8933c1259fb9698e700d55378", null ],
    [ "count_total", "structbstree.html#aacf29526945e0158819de7dc0624412b", null ],
    [ "node_total", "structbstree.html#a215aa978cf35bba1b267863484c9b026", null ],
    [ "root", "structbstree.html#ad549571392d4f2dbae0975d41d030206", null ],
    [ "unique", "structbstree.html#a0efb8e1dc5f53b2e2392c388cc651172", null ]
];