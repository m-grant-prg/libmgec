var searchData=
[
  ['mgebuffer_133',['mgebuffer',['../structmgebuffer.html',1,'']]],
  ['mgemessage_134',['mgemessage',['../structmgemessage.html',1,'']]]
];
