var searchData=
[
  ['begin_5fc_5fdecls_15',['BEGIN_C_DECLS',['../mge-portability_8h.html#a0c2d4d01206892eecb3fd695f45dec2d',1,'mge-portability.h']]],
  ['bst_5fnodes_5fduplicates_16',['BST_NODES_DUPLICATES',['../mge-bstree_8h.html#ab5e3644738fe364d904b7b4c357d0b85',1,'mge-bstree.h']]],
  ['bst_5fnodes_5funique_17',['BST_NODES_UNIQUE',['../mge-bstree_8h.html#a180030be5dfa39f8e9f9c985d24facfd',1,'mge-bstree.h']]],
  ['bstree_18',['bstree',['../structbstree.html',1,'']]],
  ['bstree_2ec_19',['bstree.c',['../bstree_8c.html',1,'']]],
  ['bstreenode_20',['bstreenode',['../structbstreenode.html',1,'']]],
  ['buffer_21',['buffer',['../structmgebuffer.html#aff2566f4c366b48d73479bef43ee4d2e',1,'mgebuffer']]],
  ['buffer_2ec_22',['buffer.c',['../buffer_8c.html',1,'']]]
];
