var searchData=
[
  ['upd_5fbst_5fnode_201',['upd_bst_node',['../mge-bstree_8h.html#a012b8ae70029c72eaaf81a0765c0e49a',1,'upd_bst_node(const struct bstree *tree, const void *updobj, size_t objsize):&#160;bstree.c'],['../bstree_8c.html#a012b8ae70029c72eaaf81a0765c0e49a',1,'upd_bst_node(const struct bstree *tree, const void *updobj, size_t objsize):&#160;bstree.c']]],
  ['upd_5fnode_202',['upd_node',['../bstree_8c.html#a73aab1f5429f1bcce37dc0592d4849d9',1,'bstree.c']]]
];
