var structmgemessage =
[
    [ "argc", "structmgemessage.html#ad1447518f4372828b8435ae82e48499e", null ],
    [ "argv", "structmgemessage.html#af2efa898e9eed6fe6715279cb1ec35b0", null ],
    [ "complete", "structmgemessage.html#af6b1fef28954e41d75acf35f76bc8d39", null ],
    [ "message", "structmgemessage.html#a0b2e8c7f76df48129f994ecc46d5c66c", null ],
    [ "next_free", "structmgemessage.html#a09030d4b2dfb90b264a8be3b93659920", null ],
    [ "separator", "structmgemessage.html#a6989953791434c8ea982054551c9e154", null ],
    [ "size", "structmgemessage.html#a854352f53b148adc24983a58a1866d66", null ],
    [ "terminator", "structmgemessage.html#a3532877d52a58d2bfeec4ce963f086a1", null ]
];