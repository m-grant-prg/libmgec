var searchData=
[
  ['mgebuffer_153',['mgebuffer',['../structmgebuffer.html',1,'']]],
  ['mgemessage_154',['mgemessage',['../structmgemessage.html',1,'']]]
];
