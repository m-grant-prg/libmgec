var searchData=
[
  ['end_5fc_5fdecls_272',['END_C_DECLS',['../portability_8h.html#ac17320fed4b28122bc4977a087b131dd',1,'portability.h']]]
];
