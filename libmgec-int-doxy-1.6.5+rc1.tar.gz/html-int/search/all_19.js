var searchData=
[
  ['ydir_148',['ydir',['../structbstobjcoord.html#ad26d97cdff72b7baf09cc7dab08ee6d7',1,'bstobjcoord']]]
];
