var portability_8h =
[
    [ "BEGIN_C_DECLS", "portability_8h.html#a0c2d4d01206892eecb3fd695f45dec2d", null ],
    [ "END_C_DECLS", "portability_8h.html#ac17320fed4b28122bc4977a087b131dd", null ],
    [ "PARAMS", "portability_8h.html#a924645a9d5499fb2d2bdcfda8d3241f0", null ]
];