var structmgebuffer =
[
    [ "buffer", "structmgebuffer.html#aff2566f4c366b48d73479bef43ee4d2e", null ],
    [ "next_free", "structmgebuffer.html#a09030d4b2dfb90b264a8be3b93659920", null ],
    [ "proc_next", "structmgebuffer.html#a3e5a8495bb79d164e56546437ac9b276", null ],
    [ "size", "structmgebuffer.html#a854352f53b148adc24983a58a1866d66", null ]
];