var searchData=
[
  ['argc_183',['argc',['../structmgemessage.html#ad1447518f4372828b8435ae82e48499e',1,'mgemessage']]],
  ['args_184',['args',['../message_8c.html#a1bd7a8575ca2650132d636d65dcda2f6',1,'message.c']]],
  ['argv_185',['argv',['../structmgemessage.html#af2efa898e9eed6fe6715279cb1ec35b0',1,'mgemessage']]]
];
