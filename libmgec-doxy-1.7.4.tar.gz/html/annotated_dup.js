var annotated_dup =
[
    [ "bstree", "structbstree.html", "structbstree" ],
    [ "bstreenode", "structbstreenode.html", "structbstreenode" ],
    [ "dllistnode", "structdllistnode.html", "structdllistnode" ],
    [ "mgebuffer", "structmgebuffer.html", "structmgebuffer" ],
    [ "mgemessage", "structmgemessage.html", "structmgemessage" ],
    [ "sllistnode", "structsllistnode.html", "structsllistnode" ]
];