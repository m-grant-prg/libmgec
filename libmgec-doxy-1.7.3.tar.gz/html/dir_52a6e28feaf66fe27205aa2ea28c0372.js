var dir_52a6e28feaf66fe27205aa2ea28c0372 =
[
    [ "buf-msg", "dir_d78e62a2cbd421971c1fc219a63b7a50.html", "dir_d78e62a2cbd421971c1fc219a63b7a50" ],
    [ "errors", "dir_8f04fa7dd355f5892809bd4a89b942b0.html", "dir_8f04fa7dd355f5892809bd4a89b942b0" ],
    [ "listsandsorts", "dir_936dec95a50173736617377efb8d602b.html", "dir_936dec95a50173736617377efb8d602b" ],
    [ "memory", "dir_3ac386e676196187e6f1542f40d57b58.html", "dir_3ac386e676196187e6f1542f40d57b58" ],
    [ "version.c", "version_8c.html", "version_8c" ]
];