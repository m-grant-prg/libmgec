var buf_msg_2internal_8h =
[
    [ "BUF_MAX_UNREACH_PERCENT", "buf-msg_2internal_8h.html#aef7265c39900560924efc2ec8249e57a", null ],
    [ "BUF_UNUSED_DEF_SIZE_MULT", "buf-msg_2internal_8h.html#afe1cdd2b075547cfb54a1333cbcfbb70", null ],
    [ "DEF_BUF_SIZE", "buf-msg_2internal_8h.html#afaf870b3cd0c265f7222b27871894a7c", null ],
    [ "DEF_MSG_SIZE", "buf-msg_2internal_8h.html#a433228a91a08544329fbdb9127073790", null ]
];