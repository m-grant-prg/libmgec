var searchData=
[
  ['trim_5fbuf_220',['trim_buf',['../mge-buffer_8h.html#adb167a2d1c26596ae70f35c495cf5286',1,'trim_buf(struct mgebuffer *msg_buf):&#160;buffer.c'],['../buffer_8c.html#a39df69216e9e8bf96ab185e3b2d85090',1,'trim_buf(struct mgebuffer *m_buf):&#160;buffer.c']]]
];
