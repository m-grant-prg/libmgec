var searchData=
[
  ['add_5fbst_5fnode_178',['add_bst_node',['../mge-bstree_8h.html#a8a0ae362f96ff51f60a04ae54560501f',1,'add_bst_node(struct bstree *tree, const void *object, size_t objsize):&#160;bstree.c'],['../bstree_8c.html#a8a0ae362f96ff51f60a04ae54560501f',1,'add_bst_node(struct bstree *tree, const void *object, size_t objsize):&#160;bstree.c']]],
  ['add_5fdll_5fnode_179',['add_dll_node',['../dllist_8h.html#a0f5e6a07c0e19ff7fb2441851184b51c',1,'add_dll_node(struct dllistnode *currentnode, const void *object, size_t objsize):&#160;dllist.c'],['../dllist_8c.html#a0f5e6a07c0e19ff7fb2441851184b51c',1,'add_dll_node(struct dllistnode *currentnode, const void *object, size_t objsize):&#160;dllist.c']]],
  ['add_5fhead_5fsll_5fnode_180',['add_head_sll_node',['../sllist_8h.html#a1356c5e949848b0ef93f55b370e06fde',1,'add_head_sll_node(struct sllistnode *head, const void *object, size_t objsize):&#160;sllist.c'],['../sllist_8c.html#a1356c5e949848b0ef93f55b370e06fde',1,'add_head_sll_node(struct sllistnode *head, const void *object, size_t objsize):&#160;sllist.c']]],
  ['add_5fnode_181',['add_node',['../bstree_8c.html#a11e4ed12cd1b235985f1fc426f4fa157',1,'bstree.c']]],
  ['add_5ftail_5fsll_5fnode_182',['add_tail_sll_node',['../sllist_8h.html#aadd80af2686ad022c8d6039db6335e4f',1,'add_tail_sll_node(struct sllistnode *head, const void *object, size_t objsize):&#160;sllist.c'],['../sllist_8c.html#aadd80af2686ad022c8d6039db6335e4f',1,'add_tail_sll_node(struct sllistnode *head, const void *object, size_t objsize):&#160;sllist.c']]]
];
