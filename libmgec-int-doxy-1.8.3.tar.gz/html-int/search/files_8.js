var searchData=
[
  ['internal_2eh_164',['internal.h',['../buf-msg_2internal_8h.html',1,'(Global Namespace)'],['../errors_2internal_8h.html',1,'(Global Namespace)'],['../listsandsorts_2internal_8h.html',1,'(Global Namespace)']]]
];
